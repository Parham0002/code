# I2C Bus

## Connections

Master(ESP32-C6) ------- Slave(MCXN236)
GND .................... GND
GPIO6(SDA) ............. P4_0(J8:4) - SDA
GPIO7(SCL) ............. P4_1(J8:3) - SCL
